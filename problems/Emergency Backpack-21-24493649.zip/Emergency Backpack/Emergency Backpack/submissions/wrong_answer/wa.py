import sys

input = sys.stdin.readline

N, W = map(int, input().split())

items = []

for _ in range(N):
    weight, value = map(int, input().split())
    items.append((weight, value))

# Sort by rescue value per unit of weight
items.sort(key=lambda item: item[1] / item[0], reverse=True)

total_weight = 0
total_value = 0

for weight, value in items:
    if total_weight + weight <= W:
        total_weight += weight
        total_value += value

print(total_value)

