import sys

input = sys.stdin.readline

N, W = map(int, input().split())

items = []
for _ in range(N):
    weight, value = map(int, input().split())
    items.append((weight, value))


def brute_force(i, current_weight, current_value):
    # All items have been considered
    if i == N:
        return current_value

    # Do not take the current item
    best = brute_force(i + 1, current_weight, current_value)

    # Take the current item if it fits
    weight, value = items[i]

    if current_weight + weight <= W:
        best = max(
            best,
            brute_force(
                i + 1,
                current_weight + weight,
                current_value + value
            )
        )

    return best


print(brute_force(0, 0, 0))    


