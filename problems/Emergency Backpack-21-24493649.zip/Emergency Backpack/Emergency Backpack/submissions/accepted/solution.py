import sys


def main():
    input = sys.stdin.readline
    
    # Read number of items and backpack capacity
    N, W = map(int, input().split())

    # dp[w] = maximum rescue value achievable with a backpack capacity of at most w
    dp = [0] * (W + 1)

    for _ in range(N):
        weight, value = map(int, input().split())

        # Iterate backwards so that each item is used at most once.
        for w in range(W, weight - 1, -1):
            dp[w] = max(dp[w], dp[w - weight] + value)

    print(dp[W])


if __name__ == "__main__":
    main()