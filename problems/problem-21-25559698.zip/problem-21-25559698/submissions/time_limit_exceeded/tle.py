N, M = map(int, input().split())

adjlist = [[] for _ in range(N)]
translist = [[] for _ in range(N)]
edges = []

for _ in range(M):
    u, v = map(int, input().split())
    u -= 1
    v -= 1

    adjlist[u].append(v)
    translist[v].append(u)
    edges.append((u, v))


def reachable(start: int, graph: list[list[int]]) -> list[bool]:
    visited = [False] * N
    stack = [start]
    visited[start] = True

    while len(stack) > 0:
        u = stack.pop()

        for v in graph[u]:
            if not visited[v]:
                visited[v] = True
                stack.append(v)

    return visited


component = [-1] * N
component_number = 0

for start in range(N):

    if component[start] != -1:
        continue

    # start 에서 갈 수 있는 곳
    forward = reachable(start, adjlist)

    # start 로 올 수 있는 곳
    backward = reachable(start, translist)

    # 둘 다 가능한 node 는 같은 SCC
    for v in range(N):
        if forward[v] and backward[v]:
            component[v] = component_number

    component_number += 1


has_incoming = [False] * component_number

for u, v in edges:
    if component[u] != component[v]:
        has_incoming[component[v]] = True


answer = 0

for x in has_incoming:
    if x == False:
        answer += 1

print(answer)