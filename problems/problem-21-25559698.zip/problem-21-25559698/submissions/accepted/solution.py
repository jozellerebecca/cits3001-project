import sys

input = sys.stdin.readline

N, M = map(int, input().split())

adjlist = [[] for _ in range(N)]
edges = []

for _ in range(M):
    u, v = map(int, input().split())
    u -= 1
    v -= 1

    adjlist[u].append(v)
    edges.append((u, v))


def transpose(adjlist: list[list[int]]) -> list[list[int]]:
    result = [[] for _ in adjlist]

    for u in range(len(adjlist)):
        for v in adjlist[u]:
            result[v].append(u)

    return result


translist = transpose(adjlist)


# first dfs
# 끝나는 순서대로 order 에 넣는다

visited = [False] * N
order = []

for start in range(N):

    if visited[start]:
        continue

    stack = [(start, 0)]

    while len(stack) > 0:

        u, state = stack.pop()

        if state == 0:

            if visited[u]:
                continue

            visited[u] = True

            # 이 노드는 나중에 끝날 때 다시 확인
            stack.append((u, 1))

            for v in adjlist[u]:
                if not visited[v]:
                    stack.append((v, 0))

        else:
            order.append(u)


# second dfs
# transpose graph 에서 SCC 찾기

component = [-1] * N
component_number = 0

for start in reversed(order):

    if component[start] != -1:
        continue

    stack = [start]
    component[start] = component_number

    while len(stack) > 0:

        u = stack.pop()

        for v in translist[u]:

            if component[v] == -1:
                component[v] = component_number
                stack.append(v)

    component_number += 1


# 각 SCC 에 다른 SCC 에서 들어오는 edge 가 있는지 확인

has_incoming = [False] * component_number

for u, v in edges:

    if component[u] != component[v]:
        has_incoming[component[v]] = True


# 들어오는 edge 가 없는 SCC 마다
# 직접 alert 를 한번 시작해야 한다

answer = 0

for x in has_incoming:
    if x == False:
        answer += 1

print(answer)