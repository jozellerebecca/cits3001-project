N, M = map(int, input().split())

indegree = [0] * N

for _ in range(M):
    u, v = map(int, input().split())
    indegree[v-1] += 1

answer = 0

for x in indegree:
    if x == 0:
        answer += 1

print(answer)


'''
A possible wrong approach is 
to count the original vertices with indegree zero. 
This fails when a source strongly connected component contains a cycle, 
because every vertex in the component may have positive indegree 
even though the component itself has no incoming edge from another component.  
'''