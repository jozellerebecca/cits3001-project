#!/usr/bin/env python3
"""Correct ending-at-mission DP, but compares every pair: O(N^2)."""
import sys


def solve(missions, cooldown):
    """Correct but deliberately slow: DP states end at a particular mission."""
    jobs = sorted(missions, key=lambda job: job[1])
    unused = []
    used = []
    answer = 0
    for i, (start, end, value) in enumerate(jobs):
        # A schedule may start at any mission without an initial recharge.
        best0 = best1 = value
        # This pairwise predecessor scan causes quadratic runtime.
        for j in range(i):
            if jobs[j][1] + cooldown <= start:
                best0 = max(best0, unused[j] + value)
                best1 = max(best1, used[j] + value)
            if jobs[j][1] <= start:
                # Spend the spare here, so the prefix must not have used it.
                best1 = max(best1, unused[j] + value)
        unused.append(best0)
        used.append(best1)
        answer = max(answer, best1)
    return answer


if __name__ == '__main__':
    read = sys.stdin.buffer.readline
    n, cooldown = map(int, read().split())
    print(solve([tuple(map(int, read().split())) for _ in range(n)], cooldown))
