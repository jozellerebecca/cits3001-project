#!/usr/bin/env python3
"""Prefix dynamic programming with two recharge states. O(N log N)."""
import sys
from bisect import bisect_right


def solve(missions, cooldown):
    """Return the maximum value achievable using the spare at most once."""
    # A mission's compatible predecessors form a prefix in return-time order.
    jobs = sorted(missions, key=lambda job: job[1])
    ends = [end for start, end, value in jobs]
    # Entry i describes the first i missions; entry 0 is the empty schedule.
    # unused: no spare allowed. available: at most one spare use allowed.
    unused = [0] * (len(jobs) + 1)
    available = [0] * (len(jobs) + 1)
    for i, (start, end, value) in enumerate(jobs, 1):
        # bisect_right includes exact equality at both timing boundaries.
        # The returned counts are also indices in the prefix DP arrays.
        normal = bisect_right(ends, start - cooldown, 0, i - 1)
        quick = bisect_right(ends, start, 0, i - 1)
        # Skip this mission, or append it after a full recharge.
        unused[i] = max(unused[i - 1], unused[normal] + value)
        # A quick transition must come from unused, preventing a second swap.
        available[i] = max(available[i - 1],
                           available[normal] + value,
                           unused[quick] + value)
    return available[-1]


def main():
    # The contest guarantees valid input; the separate validator checks tests.
    read = sys.stdin.buffer.readline
    n, cooldown = map(int, read().split())
    missions = [tuple(map(int, read().split())) for _ in range(n)]
    print(solve(missions, cooldown))


if __name__ == '__main__':
    main()
