#!/usr/bin/env python3
"""Independent event-sweep solution; readiness events go into a heap."""
import heapq
import sys


def solve(missions, cooldown):
    """Sweep departures, releasing earlier schedules when they become ready."""
    # Heap entries are (ready_time, spare_state, accumulated_value).
    events = []
    # Best ready-to-depart values with no spare used / at most one used.
    ready = [0, 0]
    answer = 0
    for start, end, value in sorted(missions):
        # Process equality before departures: a drone ready now may fly now.
        while events and events[0][0] <= start:
            time, state, score = heapq.heappop(events)
            ready[state] = max(ready[state], score)
        without = ready[0] + value
        with_spare = ready[1] + value
        # Record completion value now: a final mission needs no later recharge.
        answer = max(answer, without, with_spare)
        heapq.heappush(events, (end + cooldown, 0, without))
        # Normal recharge preserves the at-most-one-swap allowance.
        heapq.heappush(events, (end + cooldown, 1, with_spare))
        # Only an unused-spare schedule may skip recharge after this mission.
        # Positive mission durations prevent same-time self-transitions.
        heapq.heappush(events, (end, 1, without))
    return answer


if __name__ == '__main__':
    read = sys.stdin.buffer.readline
    n, cooldown = map(int, read().split())
    print(solve([tuple(map(int, read().split())) for _ in range(n)], cooldown))
