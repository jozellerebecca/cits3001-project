#!/usr/bin/env python3
"""Incorrect: greedy interval selection ignores mission values."""
import sys

def main():
    read = sys.stdin.buffer.readline
    n, cooldown = map(int, read().split())
    jobs = sorted((tuple(map(int, read().split())) for _ in range(n)), key=lambda x: x[1])
    last = None
    spare = True
    answer = 0
    # BUG: committing to the earliest finish ignores the value of alternatives.
    for s, e, v in jobs:
        if last is None or s >= last + cooldown:
            last = e
            answer += v
        # Spending the spare at the first opportunity may also be suboptimal.
        elif spare and s >= last:
            spare = False
            last = e
            answer += v
    print(answer)


if __name__ == '__main__':
    main()
