#!/usr/bin/env python3
"""Incorrect: requires normal recharge after every chosen mission."""
import sys
from bisect import bisect_right

def main():
    read = sys.stdin.buffer.readline
    n, cooldown = map(int, read().split())
    jobs = sorted((tuple(map(int, read().split())) for _ in range(n)), key=lambda x: x[1])
    ends = [e for s, e, v in jobs]
    # BUG: one state cannot express the option to skip one recharge.
    dp = [0] * (n + 1)
    for i, (s, e, v) in enumerate(jobs, 1):
        # This enforces a full recharge even when the spare is available.
        p = bisect_right(ends, s - cooldown, 0, i - 1)
        dp[i] = max(dp[i - 1], dp[p] + v)
    print(dp[-1])


if __name__ == '__main__':
    main()
