#!/usr/bin/env python3
"""Incorrect: ignores recharge, effectively allowing unlimited spares."""
import sys
from bisect import bisect_right

def main():
    read = sys.stdin.buffer.readline
    n, cooldown = map(int, read().split())
    jobs = sorted((tuple(map(int, read().split())) for _ in range(n)), key=lambda x: x[1])
    ends = [e for s, e, v in jobs]
    # BUG: treating every non-overlapping pair as compatible reuses the spare.
    dp = [0] * (n + 1)
    for i, (s, e, v) in enumerate(jobs, 1):
        # Recharge time is ignored for every transition, not just one.
        p = bisect_right(ends, s, 0, i - 1)
        dp[i] = max(dp[i - 1], dp[p] + v)
    print(dp[-1])


if __name__ == '__main__':
    main()
