#!/usr/bin/env python3
"""Incorrect: uses strict inequalities at both compatibility boundaries."""
import sys
from bisect import bisect_left

def main():
    read = sys.stdin.buffer.readline
    n, cooldown = map(int, read().split())
    jobs = sorted((tuple(map(int, read().split())) for _ in range(n)), key=lambda x: x[1])
    ends = [e for s, e, v in jobs]
    # These two states are correct; only the boundary comparisons are wrong.
    unused = [0] * (n + 1)
    available = [0] * (n + 1)
    for i, (s, e, v) in enumerate(jobs, 1):
        # BUG: bisect_left rejects equality, although both rules allow it.
        p = bisect_left(ends, s - cooldown, 0, i - 1)
        q = bisect_left(ends, s, 0, i - 1)
        unused[i] = max(unused[i - 1], unused[p] + v)
        available[i] = max(available[i - 1], available[p] + v, unused[q] + v)
    print(available[-1])


if __name__ == '__main__':
    main()
