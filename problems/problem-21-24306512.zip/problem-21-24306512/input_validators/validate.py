#!/usr/bin/env python3
"""Strict input-format validator; Kattis success exit code is 42."""
import re
import sys


def require(condition, message):
    if not condition:
        print(message, file=sys.stderr)
        sys.exit(43)


def read_numbers(count):
    line = sys.stdin.buffer.readline()
    pattern = rb'(0|[1-9][0-9]*)' + rb' (0|[1-9][0-9]*)' * (count - 1) + rb'\n'
    require(re.fullmatch(pattern, line) is not None, 'Invalid line format')
    return list(map(int, line.split()))


n, cooldown = read_numbers(2)
require(1 <= n <= 200000 and 0 <= cooldown <= 10**9, 'Header outside bounds')
for _ in range(n):
    start, end, value = read_numbers(3)
    require(0 <= start < end <= 10**9 and 1 <= value <= 10**9, 'Mission outside bounds')
require(sys.stdin.buffer.read() == b'', 'Extra input after final mission')
sys.exit(42)
