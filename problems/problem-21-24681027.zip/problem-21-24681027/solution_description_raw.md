# Assignment Crunch - Solution Description

## Overview

Assignment Crunch is a scheduling problem where each assignment has a
duration and a deadline. The goal is to complete the maximum possible
number of assignments on time.

The solution uses a greedy algorithm with a priority queue. Assignments
are first sorted by deadline. They are then considered one at a time
while keeping track of the assignments currently selected and their
total duration. Whenever the total duration becomes greater than the
current deadline, the selected assignment with the longest duration is
removed. Removing the longest assignment frees the greatest amount of
time while only removing one assignment.

## Algorithm

1.  Sort all assignments in increasing order of deadline.
2.  Keep a running total of the time needed for the assignments
    currently selected.
3.  Store the durations of selected assignments in a max-priority queue.
4.  For each assignment, add its duration to the total and to the
    priority queue. If the total exceeds the current deadline, remove
    the longest assignment and subtract its duration from the total.
5.  After all assignments have been considered, the number remaining in
    the priority queue is the maximum number that can be completed on
    time.

## Pseudocode

``` text
sort assignments by deadline
total_time = 0
selected = empty max-priority queue

for each assignment in sorted assignments:
    total_time = total_time + assignment.duration
    add assignment.duration to selected

    if total_time > assignment.deadline:
        longest = remove maximum from selected
        total_time = total_time - longest

return size of selected
```

## Complexity Analysis

Sorting the assignments by deadline takes O(n log n) time. Each
assignment is added to the priority queue once and can be removed at
most once, and each priority queue operation takes O(log n) time.
Therefore, the overall time complexity is O(n log n). The priority queue
can contain up to n assignments, so the space complexity is O(n).

## AI Use Declaration

I used ChatGPT as a support tool while developing this problem. It
assisted with refining the problem statement, discussing the greedy
approach, code debugging and reviewing the problem package. I made the
final design decisions and reviewed, tested, and verified the submitted
solutions and test data myself.
