import sys
import re

def fail():
    sys.exit(1)

integer = r"(0|[1-9][0-9]*)"

# First line: exactly one integer followed by newline
line = sys.stdin.readline()

if not re.fullmatch(integer + r"\n", line):
    fail()

n = int(line)

if not (1 <= n <= 200000):
    fail()

# Next n lines: exactly "t d\n"
for _ in range(n):
    line = sys.stdin.readline()

    match = re.fullmatch(
        rf"({integer}) ({integer})\n",
        line
    )

    if not match:
        fail()

    t = int(match.group(1))
    d = int(match.group(3))

    if not (1 <= t <= 10**9):
        fail()

    if not (1 <= d <= 10**9):
        fail()

# Nothing allowed after the n assignment lines
if sys.stdin.read() != "":
    fail()

sys.exit(42)