n = int(input())

assignments = []

for _ in range(n):
    time, deadline = map(int, input().split())
    assignments.append((deadline, time))

assignments.sort()

chosen = []
total_time = 0

for deadline, time in assignments:
    chosen.append(time)
    total_time += time

    if total_time > deadline:
        longest = max(chosen)
        chosen.remove(longest)
        total_time -= longest

print(len(chosen))