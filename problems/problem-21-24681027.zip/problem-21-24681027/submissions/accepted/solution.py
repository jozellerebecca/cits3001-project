import sys
import heapq

input = sys.stdin.readline

n = int(input())

assignments = []

for _ in range(n):
    time, deadline = map(int, input().split())
    assignments.append((deadline, time))

assignments.sort()

chosen = []
total_time = 0

for deadline, time in assignments:
    total_time += time
    heapq.heappush(chosen, -time)

    if total_time > deadline:
        longest = -heapq.heappop(chosen)
        total_time -= longest

print(len(chosen))