n = int(input())

assignments = []

for _ in range(n):
    time, deadline = map(int, input().split())
    assignments.append((time, deadline))

# Incorrect idea:
# always complete the shortest assignments first
assignments.sort()

current_time = 0
completed = 0

for time, deadline in assignments:
    if current_time + time <= deadline:
        current_time += time
        completed += 1

print(completed)